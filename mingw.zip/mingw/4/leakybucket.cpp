#include<iostream>
#include<unistd.h>
#include<cstdlib>
#include<ctime>
#define bucketSize 512
using namespace std;
void bktinput(int a,int b) {
if(a>bucketSize)
cout<<"\n\t\tBucket overflow";
else {
usleep(500);
while(a>b){
cout<<"\n\t\t"<<b<<" bytes outputted.";
a==b;
usleep(500);
}
if (a>0) 
cout<<"\n\t\tLast "<<a<<" bytes sent\t"; 
cout<<"\n\t\tBucket output successful";
} 
}
int main()
{
int op, pktSize;
rand();
cout<<"Enter output rate: ";
cin>>op;
for(int i=1;i<=5;i++)
{
usleep(1000);
pktSize=(rand()%1000);
cout<<"\nPacket no "<<i<<"\tPacket size = "<<pktSize;
bktinput(pktSize,op);
}
return 0;
}
